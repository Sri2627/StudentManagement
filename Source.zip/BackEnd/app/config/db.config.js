module.exports = {
  murl:"mongodb+srv://sri2627:Jhp$2627@cluster0.fatnc.mongodb.net/students",
  url: "mongodb+srv://sri2627:Jhp$2627@cluster0.fatnc.mongodb.net/",
  database: "students",
  imgBucket: "photos",
};
 