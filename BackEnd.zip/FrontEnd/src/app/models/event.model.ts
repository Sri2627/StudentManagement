export class EVENT {
    id?: any;
    title?: string;
    description?: string;
    date?: string;
    studentid?: string;
    customerid?: string;
    published?: boolean;
    createdAt?: string;
    
  }