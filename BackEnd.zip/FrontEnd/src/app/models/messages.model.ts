export class Messages {
    id?: any;
    messagetitle?: string;
    mbody?: string;
    name?: string;
    studentid?: string;
    teacherid?: string;
    published?: boolean;
  }