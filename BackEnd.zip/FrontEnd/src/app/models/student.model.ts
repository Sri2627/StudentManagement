export class Students{

    _id: string='';
    username: string='';
    email: string='';
    password: string='';
    admissionno: string='';
    roles: any;
    fullname:  String='';
    mobile: String='';
    address: String='';
    standard: String='';
    section: String='';
    profile: String='';
    photourl: String='';
    subject: String='';
    mysections: String='';

 
}


