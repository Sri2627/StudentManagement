module.exports = {
  murl:"mongodb+srv://sri2627:Rama$9897@cluster0.fatnc.mongodb.net/students",
  url: "mongodb+srv://sri2627:Rama$9897@cluster0.fatnc.mongodb.net/",
  database: "students",
  imgBucket: "photos",
};
 