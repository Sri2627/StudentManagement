module.exports = {
  secret: "srikanth-secret-key"
};
