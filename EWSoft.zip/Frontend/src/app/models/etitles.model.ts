 export class EXAMTITLE {
    id?: any;
    title?:  String;
    description?: String;
    section?: String;

  }