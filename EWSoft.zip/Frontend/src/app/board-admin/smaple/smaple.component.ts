import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-smaple',
  templateUrl: './smaple.component.html',
  styleUrls: ['./smaple.component.css']
})
export class SmapleComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
